
surg = read.table("surg.dat",header = TRUE)



plot(surg)

Gender variable appears to be categorical based off the scatterplot.
Liver and survival have a slightly linear relationship. also enzyme and survival also have a slight linear relationship.

the correlation matrix will not work because gender is categorical variable and correlation matrix requires numeric variables.


surgclean <- surg
surgclean <- surg[,-6]



cor(surgclean)

There is a strong  positive correlation between survival and every variable besides age that has a negative correlation.

surg.1 = lm(survival~blood+prognosis+enzyme+liver+age,data= surg)

summary(surg.1)

par(mfrow = c(1, 2))



plot(surg.1, which = 1:2)


par(mfrow = c(2, 2))


plot(resid(surg.1)~blood+prognosis+enzyme+liver+age, data = surg)


checking assumptions.
The Fitted vs residuals has a significant curvature indicating it may not be normally distributed
The normal QQ plot also has a slight curvature indicating the relationship may not be linear, however there is an outlier and this may be the cause for the curvature.
the residuals vs predictors look concentrated could be a potential pattern.


mathematical equation
$$Y = \beta_0+\beta_1x_1+\beta_2x_2+\beta_3x_3+\beta_4x_4+\beta_5x_5+\epsilon;\epsilon \sim N(0,\sigma^2)$$
  defining parameters
$$Y_i = survival$$
$$X_1 = blood$$
$$X_2 = prognosis$$
$$X_3 = enzyme$$
$$X_4 = liver$$
$$X_5 = age$$
$$Hypothesis\\H~0~:\beta_1 = \beta_2 =\beta_3=\beta_4=\beta_5=  0 \\H~1~ : \beta_i\not= 0$$

produce anova table

surg.1 = lm(survival~blood+prognosis+enzyme+liver+age, data = surg)


anova(surg.1)

Liver and age don't have significant p values.
will remove liver because has the highest p value and check diagnostics.

totalregSS = 1005152+1278496+3442172+57862+33032


surg.2 = lm(survival~blood+prognosis+enzyme+age, data = surg)


anova(surg.2)

age still does not have a significant p value need to remove.

surg.3 = lm(survival~blood+prognosis+enzyme, data = surg)

anova(surg.3)

checking diagnostics

par(mfrow = c(1, 2))

plot(surg.3, which = 1:2)

the Residauls vs fitted and QQplot still have curvatures.

compute F stat


totalregSS = 1005152+1278496+3442172+57862+33032
regms <- totalregSS/5
resms <-53183
ftest= regms/resms
ftest

the null distribution is that none of the predictor #variables have an effect on survival time from liver #operation.


conclusion.
After backwise step method all predictor variables have significant p values.
The F static is greater than the p value meaning we need #to reject null hypothesis.
Contextually the removal of liver and age variables is not correct because they are dependent variables
the outliers from survival look to have created a curvature in the residuals vs fitted and normal QQ plot.

surgliver=lm(survival~liver+I(liver^2)+I(liver^3)+I(liver^4), data = surgclean)


anova(surgliver)


surgage=lm(survival~age+I(age^2)+I(age^3)+I(age^3)+I(age^4)+I(age^5)+I(age^6), data = surgclean)

anova(surgage)

fitting the model with quadratic model

surgquad = lm(survival~blood+prognosis+enzyme+I(liver^4), data =surgclean)

anova(surgquad)

plot(surgquad, which = 1:2)

It is not appropriate to use the multiple regression model because the assumptions have not been met all of the QQplots are not linear and the residuals vs fitted all have curvature.

surgclean$survival = log(surgclean$survival)
surglog = lm(survival~blood+prognosis+enzyme+liver+age, data = surgclean)

plot(surglog)



pairs(survival~blood+prognosis+enzyme+liver+age, data = surgclean, panel = panel.smooth)

par(mfrow = c(2, 2))

plot(surglog, which = 1:2)



plot(resid(surglog)~blood+prognosis+enzyme+liver+age, data = surgclean)



anova(surglog)


The use of logarithm helps by clarifying the exponential data increase instead of using the survival data set that has significant outlier.
This is shown in the residuals where all three assumptions homoscedasticity, normality and un-correlatedness have been met.

kml = read.table("kml.dat", header = TRUE)

table(kml[, c("driver","car")])

design is balanced we can see from looking at the table there is an equal amount of variables.


boxplot(kmL~driver+car, data = kml)

variances do not look to be equal, and the averages have a large variance between variables.

interaction.plot(kml$car,kml$driver,kml$kmL)

interaction.plot(kml$driver,kml$car,kml$kmL)

The lines are parallel indicating a lack of interaction occurring between variables.

anova two way model
$$Y{ijk}\ = \mu+\alpha_i+\beta_j+\gamma_ij+\epsilon_ijk$$
 
defining parameters
 
$${ij} = interaction\ of\  driver \ and \ car $$
$${i} = driver$$
$${j} = car$$
 
Three tests to be conducted
 
The interaction
 
$$H~0~:\gamma_ij = 0\\H~A~:\gamma_ij\neq 0$$
Main effect of driver
$$H~0~:\alpha_i = 0\\H~A~:\alpha_i\neq 0$$
main effect of car
$$H~0~:\beta_j = 0\\H~A~:\beta_j\neq 0$$

kmlanova = aov(kmL~driver+car+driver:car, data = kml)



anova(kmlanova)


interaction effect

$$ model =\mu+\alpha_i+\beta_j+\gamma_ij+\epsilon$$
$$Hypotheses:\\ H~0~:\gamma_ij = 0\\H~A~:\gamma_ij\neq 0$$
P-value = 0.3715 > 0.05
 
interaction is not significant because p value is not significant

kmlanova.1 = aov(kmL~driver+car, data = kml)



anova(kmlanova.1)

Driver effect

$$ model = \mu+\alpha_i+\beta_j+\gamma_ij$$
$$Hypothese\\H~0~:\alpha_i = 0\\H~A~:\alpha_i\neq 0$$
P value = 0.00000000000000022 > 0.05
 
driver type is significant
Car effect
 
$$ model = \mu+\alpha_i+\beta_j+\gamma_ij$$
$$Hypothese\\H~0~:\beta_j = 0\\H~A~:\beta_j\neq 0$$
 
p value = 0.00000000000000022 > 0.05
 
car type is significant

plot(kmlanova.1)

residuals look to be normally distributed.
assumption of normal distribution looks to be valid.

p value is insignificant assumption not valid.

conclusion
The effect of driver and car on fuel efficiency insignificant however individual interactions of car and drive separately on fuel efficiency are significant.

The interaction plot shows that there is no strong interaction between variables.

would need to reject alternate hypothesis for overall effect of car and driver on fuel efficiency.